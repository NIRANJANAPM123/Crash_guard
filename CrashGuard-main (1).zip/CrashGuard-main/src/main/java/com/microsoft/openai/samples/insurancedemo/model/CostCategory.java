package com.microsoft.openai.samples.insurancedemo.model;

public enum CostCategory {
    MINOR,
    MEDIUM,
    SEVERE
}
