package com.microsoft.openai.samples.insurancedemo.model;

public enum DamageType {
    CAR_INSURANCE,
    HOUSEHOLDER_INSURANCE,
    OTHER
}
