package com.microsoft.openai.samples.insurancedemo.model;

public enum CarInsuranceType {
    THEFT,
    PARKING_DAMAGE,
    BROKEN_GLASS,
    OTHER
}

