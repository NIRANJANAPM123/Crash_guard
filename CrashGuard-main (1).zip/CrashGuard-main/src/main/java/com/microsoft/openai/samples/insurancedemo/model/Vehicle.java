package com.microsoft.openai.samples.insurancedemo.model;

public record Vehicle(String make, String model, String color, int registrationYear, String plateNumber) {}
