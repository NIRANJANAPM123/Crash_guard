package com.microsoft.openai.samples.insurancedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceDemoApplication.class, args);
	}

}
