package com.microsoft.openai.samples.insurancedemo.model;

public record CoverageDetails(boolean comprehensive, boolean parkingDamageInsurance) {
}
